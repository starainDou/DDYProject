//
//  DDYQRCodeScanResultVC.h
//  DDYProject
//
//  Created by LingTuan on 17/8/11.
//  Copyright © 2017年 Starain. All rights reserved.
//  https://github.com/starainDou/DDYProject/tree/master/DDYProject/CoreImage/QRCode

#import <UIKit/UIKit.h>

@interface DDYQRCodeScanResultVC : UIViewController

@property (nonatomic, strong) NSString *resultStr;

@end
