//
//  NSDate+DDYExtension.h
//  DDYProject
//
//  Created by Starain on 16/9/3.
//  Copyright © 2016年 Starain. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (DDYExtension)

/** yyyy年MM月dd日 或 yyyy-MM-dd*/
+ (NSDate *)DDYDateFromString:(NSString *)dateStr ;

@end
